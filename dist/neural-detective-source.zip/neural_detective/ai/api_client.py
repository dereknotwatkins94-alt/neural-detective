"""Заменяемый клиент официального google-genai SDK."""
import json
from typing import Protocol
from ai.prompts import SYSTEM_PROMPT


class AIProvider(Protocol):
    name: str

    def choose(self, request: dict) -> dict: ...


class ProviderError(Exception):
    """Публичная ошибка без ключей и содержимого запроса."""


class GeminiProvider:
    name = "GEMINI"

    def __init__(self, api_key: str, model: str, timeout_ms: int = 20000):
        self.api_key = api_key
        self.model = model
        self.timeout_ms = timeout_ms

    def _client(self):
        from google import genai
        from google.genai import types
        return genai.Client(api_key=self.api_key, http_options=types.HttpOptions(
            timeout=self.timeout_ms, retry_options=types.HttpRetryOptions(attempts=1)))

    def choose(self, request: dict) -> dict:
        from google.genai import types
        schema = {'type':'object', 'properties':{
            'topic': {'type':'string', 'enum':list(request['candidates'])},
            'reaction': {'type':'string', 'enum':['neutral','guarded','nervous','cooperative']},
            'order': {'type':'array', 'items':{'type':'integer'}}},
            'required':['topic','reaction','order'], 'additionalProperties':False}
        try:
            with self._client() as client:
                response = client.models.generate_content(model=self.model, contents=json.dumps(request, ensure_ascii=False), config=types.GenerateContentConfig(
                    system_instruction=SYSTEM_PROMPT, response_mime_type='application/json',
                    response_json_schema=schema, temperature=0.5, max_output_tokens=1024))
                return json.loads(response.text or '{}')
        except Exception as error:
            code = getattr(error, 'code', None)
            message = "Лимит запросов Gemini исчерпан." if code == 429 else "Gemini недоступен: проверьте ключ, модель и сеть."
            raise ProviderError(message) from None

    def check(self) -> str:
        try:
            with self._client() as client:
                response = client.models.generate_content(model=self.model, contents='Ответь одним словом: OK', config={'max_output_tokens':64})
                if not response.text:
                    raise ProviderError('Модель не вернула ответ.')
            return 'GEMINI CONNECTED'
        except Exception:
            raise ProviderError('Проверка не прошла: проверьте API-ключ, модель, доступность сервиса и лимиты.') from None
